﻿################################
### Galaxietool / Galaxytool ###
################################

Hi all,

this tool has its install instructions at:
http://en.wiki.galaxytool.eu/index.php/Installation (English)
http://de.wiki.galaxytool.eu/index.php/Installation (German)
http://es.wiki.galaxytool.eu/index.php/Instalación (Spanish)

The information needed for an update are located at:
http://en.wiki.galaxytool.eu/index.php/Updates (English)
http://de.wiki.galaxytool.eu/index.php/Update (German)
http://es.wiki.galaxytool.eu/index.php/Updates (Spanish)
