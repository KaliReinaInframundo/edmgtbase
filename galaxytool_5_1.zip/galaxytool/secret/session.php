<?php
require "../config/config.php";
require "../config/attributes.php";
session_start();
?>
<html>
<meta http-equiv="refresh" content="1000; URL=session.php">
</html>
