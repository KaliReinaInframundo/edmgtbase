dojo.require("dijit.Tooltip");function galaxytool_view_init(){}dojo.ready(galaxytool_view_init);
