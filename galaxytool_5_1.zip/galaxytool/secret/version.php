<?php
if (!defined("VERSION")) define("VERSION","v5.1");
if (!defined("PLUGIN_VERSION")) define("PLUGIN_VERSION","2.6.12"); // always use 3 digits here! e.g. 3.0.0
?>