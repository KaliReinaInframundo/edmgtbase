<?php

require "firefox.php";

exit();
